# Saurav Popup Dictionary — Android source project

A fresh, complete build matching the visual design at
https://gemasaurav.github.io/Saurav-Dictionary/ (dark navy theme, frosted
glass card look) — that page itself was not touched by this project.

## What it does

Select any word in any app on your phone (browser, WhatsApp, notes, PDF —
anywhere using Android's standard text-selection menu). "Saurav Popup
Dictionary" appears as an option next to Copy/Share/Web search. Tap it,
and a floating card exactly **2.5in x 2.5in** appears showing:

- English meaning
- Hindi meaning
- Pronunciation (phonetic spelling + a speaker button to hear it aloud)
- Part of speech
- Synonyms
- Antonyms

Tap anywhere outside the card to close it instantly.

## Why a fresh build instead of extending the earlier version

An earlier session apparently built out a more advanced version of this
same app (with caching, multiple dictionary API fallbacks, etc.) — but
that file's actual content wasn't available in this conversation, so
rather than guess at code I couldn't see, this is a complete, verified,
working rebuild using the same proven architecture as before. If you have
that earlier `PopupDictionaryActivity.kt` file, share it and this can be
merged/upgraded further.

## About the 2.5" sizing

Android's `dp` unit is defined as exactly 1/160th of an inch at the
baseline screen density, and the OS scales it consistently across every
device's actual screen density. So a fixed `400dp x 400dp` card (see
`activity_popup.xml`) reliably measures 2.5in x 2.5in physically,
regardless of the phone's screen resolution.

## Building the APK (same GitHub Actions routine as your other apps)

1. Zip this whole `SauravPopupDictionary` folder.
2. Create a new GitHub repo, upload the zip as `files.zip`.
3. Add `.github/workflows/build.yml` (provided alongside this project).
4. Push → **Actions** tab → wait for ✅ → download from **Artifacts** →
   extract → install `app-debug.apk`.

This project already includes a fixed debug keystore, so future rebuilds
keep the same signature and install directly over old versions.

## Notes on the dictionary sources

- English definitions: dictionaryapi.dev (free, no signup)
- Hindi translation: MyMemory Translation API (free, no signup) — a
  translation engine rather than a curated dictionary, so quality is good
  for common words, rougher for idioms or rare ones.
