package com.saurav.popupdictionary

import android.content.Intent
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.view.View
import android.widget.ImageButton
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Locale

/**
 * Shown when the user selects a word in any app and taps "Saurav Popup
 * Dictionary" in the text-selection toolbar. Displayed as an adaptive
 * floating card (see activity_popup.xml + PopupDialogTheme) that closes
 * when the user taps outside it.
 */
class PopupDictionaryActivity : AppCompatActivity(), TextToSpeech.OnInitListener {

    private lateinit var tvWord: TextView
    private lateinit var tvPhonetic: TextView
    private lateinit var tvPartOfSpeech: TextView
    private lateinit var tvMeaningEn: TextView
    private lateinit var tvHindiLabel: TextView
    private lateinit var tvMeaningHi: TextView
    private lateinit var tvSynonymsLabel: TextView
    private lateinit var tvSynonyms: TextView
    private lateinit var tvAntonymsLabel: TextView
    private lateinit var tvAntonyms: TextView
    private lateinit var progressBar: ProgressBar
    private lateinit var btnSpeak: ImageButton

    private var tts: TextToSpeech? = null
    private var currentWord: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_popup)

        tvWord = findViewById(R.id.tvWord)
        tvPhonetic = findViewById(R.id.tvPhonetic)
        tvPartOfSpeech = findViewById(R.id.tvPartOfSpeech)
        tvMeaningEn = findViewById(R.id.tvMeaningEn)
        tvHindiLabel = findViewById(R.id.tvHindiLabel)
        tvMeaningHi = findViewById(R.id.tvMeaningHi)
        tvSynonymsLabel = findViewById(R.id.tvSynonymsLabel)
        tvSynonyms = findViewById(R.id.tvSynonyms)
        tvAntonymsLabel = findViewById(R.id.tvAntonymsLabel)
        tvAntonyms = findViewById(R.id.tvAntonyms)
        progressBar = findViewById(R.id.progressBar)
        btnSpeak = findViewById(R.id.btnSpeak)

        tts = TextToSpeech(this, this)
        btnSpeak.setOnClickListener {
            if (currentWord.isNotBlank()) {
                tts?.speak(currentWord, TextToSpeech.QUEUE_FLUSH, null, "utt1")
            }
        }

        val selected = intent?.getCharSequenceExtra(Intent.EXTRA_PROCESS_TEXT)?.toString()?.trim()

        if (selected.isNullOrBlank()) {
            Toast.makeText(this, "No word selected", Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        // Clean the selected text: take first token and strip punctuation
        currentWord = selected
            .split(Regex("\\s+"))
            .firstOrNull { it.isNotBlank() }
            ?.replace(Regex("[^\\p{L}\\p{N}'-]"), "")
            ?.trim()
            ?: selected.trim()

        if (currentWord.isBlank()) {
            Toast.makeText(this, "No valid word selected", Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        tvWord.text = currentWord
        setResultTextsVisible(false)
        progressBar.visibility = View.VISIBLE

        lookupWord(currentWord)
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts?.language = Locale.US
        }
    }

    private fun setResultTextsVisible(visible: Boolean) {
        val v = if (visible) View.VISIBLE else View.GONE
        tvPhonetic.visibility = v
        tvPartOfSpeech.visibility = v
        tvMeaningEn.visibility = v
        tvHindiLabel.visibility = v
        tvMeaningHi.visibility = v
        // synonyms / antonyms stay GONE until we have data
        if (!visible) {
            tvSynonymsLabel.visibility = View.GONE
            tvSynonyms.visibility = View.GONE
            tvAntonymsLabel.visibility = View.GONE
            tvAntonyms.visibility = View.GONE
        }
    }

    private fun lookupWord(word: String) {
        Thread {
            var phonetic = ""
            var partOfSpeech = ""
            var meaningEn = ""
            val synonyms = mutableListOf<String>()
            val antonyms = mutableListOf<String>()
            var success = false
            var errorMessage: String? = null

            try {
                val encoded = URLEncoder.encode(word, "UTF-8")
                val url = URL("https://api.dictionaryapi.dev/api/v2/entries/en/$encoded")
                val conn = url.openConnection() as HttpURLConnection
                conn.requestMethod = "GET"
                conn.connectTimeout = 12000
                conn.readTimeout = 12000
                conn.setRequestProperty("User-Agent", "SauravPopupDictionary/1.0 (Android)")
                conn.setRequestProperty("Accept", "application/json")
                conn.instanceFollowRedirects = true

                val code = conn.responseCode
                if (code == 200) {
                    val body = conn.inputStream.bufferedReader().use { it.readText() }
                    val arr = JSONArray(body)
                    if (arr.length() > 0) {
                        val entry = arr.getJSONObject(0)

                        phonetic = entry.optString("phonetic", "")
                        if (phonetic.isBlank()) {
                            val phonetics = entry.optJSONArray("phonetics")
                            if (phonetics != null) {
                                for (i in 0 until phonetics.length()) {
                                    val p = phonetics.getJSONObject(i).optString("text", "")
                                    if (p.isNotBlank()) {
                                        phonetic = p
                                        break
                                    }
                                }
                            }
                        }

                        val meanings = entry.optJSONArray("meanings")
                        if (meanings != null && meanings.length() > 0) {
                            val firstMeaning = meanings.getJSONObject(0)
                            partOfSpeech = firstMeaning.optString("partOfSpeech", "")

                            val definitions = firstMeaning.optJSONArray("definitions")
                            if (definitions != null && definitions.length() > 0) {
                                meaningEn = definitions.getJSONObject(0).optString("definition", "")
                            }

                            for (m in 0 until meanings.length()) {
                                val meaning = meanings.getJSONObject(m)
                                collectStrings(meaning.optJSONArray("synonyms"), synonyms)
                                collectStrings(meaning.optJSONArray("antonyms"), antonyms)
                                val defs = meaning.optJSONArray("definitions")
                                if (defs != null) {
                                    for (d in 0 until defs.length()) {
                                        val defObj = defs.getJSONObject(d)
                                        collectStrings(defObj.optJSONArray("synonyms"), synonyms)
                                        collectStrings(defObj.optJSONArray("antonyms"), antonyms)
                                    }
                                }
                            }
                        }
                        success = meaningEn.isNotBlank()
                        if (!success) {
                            errorMessage = getString(R.string.not_found)
                        }
                    } else {
                        errorMessage = getString(R.string.not_found)
                    }
                } else if (code == 404) {
                    errorMessage = getString(R.string.not_found)
                } else {
                    errorMessage = getString(R.string.network_error)
                }
                conn.disconnect()
            } catch (e: java.net.UnknownHostException) {
                errorMessage = getString(R.string.network_error)
            } catch (e: java.net.SocketTimeoutException) {
                errorMessage = getString(R.string.network_error)
            } catch (e: java.io.IOException) {
                errorMessage = getString(R.string.network_error)
            } catch (e: Exception) {
                // JSON or unexpected
                errorMessage = getString(R.string.not_found)
            }

            // Hindi translation (best-effort, never blocks the English result)
            var meaningHi = ""
            try {
                val q = URLEncoder.encode(word, "UTF-8")
                val hiUrl = URL("https://api.mymemory.translated.net/get?q=$q&langpair=en|hi")
                val hiConn = hiUrl.openConnection() as HttpURLConnection
                hiConn.requestMethod = "GET"
                hiConn.connectTimeout = 10000
                hiConn.readTimeout = 10000
                hiConn.setRequestProperty("User-Agent", "SauravPopupDictionary/1.0 (Android)")
                if (hiConn.responseCode == 200) {
                    val body = hiConn.inputStream.bufferedReader().use { it.readText() }
                    val json = JSONObject(body)
                    meaningHi = json.optJSONObject("responseData")
                        ?.optString("translatedText", "") ?: ""
                }
                hiConn.disconnect()
            } catch (_: Exception) {
                // silently skip Hindi if it fails
            }

            val finalPhonetic = phonetic
            val finalPos = partOfSpeech
            val finalMeaningEn = meaningEn
            val finalMeaningHi = meaningHi
            val finalSuccess = success
            val finalError = errorMessage

            runOnUiThread {
                progressBar.visibility = View.GONE
                if (!finalSuccess) {
                    tvMeaningEn.visibility = View.VISIBLE
                    tvMeaningEn.text = finalError ?: getString(R.string.not_found)
                    return@runOnUiThread
                }

                setResultTextsVisible(true)
                tvPhonetic.text = finalPhonetic
                tvPhonetic.visibility = if (finalPhonetic.isBlank()) View.GONE else View.VISIBLE

                tvPartOfSpeech.text = finalPos
                tvPartOfSpeech.visibility = if (finalPos.isBlank()) View.GONE else View.VISIBLE

                tvMeaningEn.text = finalMeaningEn

                if (finalMeaningHi.isNotBlank()) {
                    tvMeaningHi.text = finalMeaningHi
                    tvHindiLabel.visibility = View.VISIBLE
                    tvMeaningHi.visibility = View.VISIBLE
                } else {
                    tvHindiLabel.visibility = View.GONE
                    tvMeaningHi.visibility = View.GONE
                }

                if (synonyms.isNotEmpty()) {
                    tvSynonymsLabel.visibility = View.VISIBLE
                    tvSynonyms.visibility = View.VISIBLE
                    tvSynonyms.text = synonyms.take(6).joinToString(", ")
                }
                if (antonyms.isNotEmpty()) {
                    tvAntonymsLabel.visibility = View.VISIBLE
                    tvAntonyms.visibility = View.VISIBLE
                    tvAntonyms.text = antonyms.take(6).joinToString(", ")
                }
            }
        }.start()
    }

    private fun collectStrings(arr: JSONArray?, into: MutableList<String>) {
        if (arr == null) return
        for (i in 0 until arr.length()) {
            val s = arr.optString(i, "")
            if (s.isNotBlank() && !into.contains(s)) into.add(s)
        }
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}
