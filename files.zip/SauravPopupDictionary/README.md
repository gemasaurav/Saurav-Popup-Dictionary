# Saurav Popup Dictionary — Android source project

A complete, ready-to-build popup dictionary for Android.

## What it does

Select any word in any app (browser, WhatsApp, notes, PDF, etc.).  
In the system text-selection toolbar, choose **Saurav Popup Dictionary**.  
A floating glass-style card appears with:

- English meaning
- Hindi translation
- Phonetic pronunciation + speak button
- Part of speech
- Synonyms & antonyms

Tap outside the card to dismiss it.

## Fixes applied (Sept 2026)

1. **Screen fitting**  
   The old fixed `400dp × 400dp` card overflowed on most phones.  
   It is now adaptive: `match_parent` width (capped at 320 dp) and `wrap_content` height with a ScrollView, so the full definition is always readable.

2. **"Couldn't reach the dictionary"**  
   - Cleaner selected-word extraction (strips punctuation).  
   - Proper User-Agent + longer timeouts.  
   - More precise error handling (network vs not-found).  
   - Hindi translation remains best-effort and never blocks English results.

## How to build the APK

### Option A – GitHub Actions (recommended)
1. Zip the entire `SauravPopupDictionary` folder.
2. Create a new GitHub repository.
3. Upload the zip as `files.zip` in the root.
4. Add the workflow file `.github/workflows/build-apk.yml` (see earlier corrected version).
5. Push → Actions tab → download the artifact.

### Option B – Local Android Studio
1. Open the project in Android Studio (Giraffe or newer).
2. Let it sync Gradle.
3. Build → Build Bundle(s) / APK(s) → Build APK(s).
4. Install the debug APK.

The project already contains a fixed debug keystore, so successive builds keep the same signature and can be installed over previous versions.

## Dictionary sources
- English: https://api.dictionaryapi.dev (free, no key)
- Hindi: MyMemory Translation API (free, no key)

## Requirements
- minSdk 24
- targetSdk / compileSdk 34
- Internet permission (already declared)
