package com.saurav.popupdictionary

import android.content.Intent
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.util.DisplayMetrics
import android.view.View
import android.view.WindowManager
import android.widget.ImageButton
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Locale

/**
 * Floating popup dictionary.
 * - English word → meaning + Hindi (default)
 * - Hindi word → English translation + English definition
 * Offline list for common words; three free online APIs for everything else.
 * Large adaptive card so text is never cut off.
 */
class PopupDictionaryActivity : AppCompatActivity(), TextToSpeech.OnInitListener {

    private lateinit var tvWord: TextView
    private lateinit var tvPhonetic: TextView
    private lateinit var tvPartOfSpeech: TextView
    private lateinit var tvMeaningEn: TextView
    private lateinit var tvHindiLabel: TextView
    private lateinit var tvMeaningHi: TextView
    private lateinit var tvSynonymsLabel: TextView
    private lateinit var tvSynonyms: TextView
    private lateinit var tvAntonymsLabel: TextView
    private lateinit var tvAntonyms: TextView
    private lateinit var progressBar: ProgressBar
    private lateinit var btnSpeak: ImageButton

    private var tts: TextToSpeech? = null
    private var currentWord: String = ""
    private var isHindiInput: Boolean = false

    data class DictResult(
        val phonetic: String = "",
        val partOfSpeech: String = "",
        val meaning: String = "",
        val hindi: String = "",
        val synonyms: List<String> = emptyList(),
        val antonyms: List<String> = emptyList()
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_popup)

        // Use ~92% of screen width so the popup is large and readable
        window?.let { w ->
            val metrics = DisplayMetrics()
            @Suppress("DEPRECATION")
            w.windowManager.defaultDisplay.getMetrics(metrics)
            val params = w.attributes
            params.width = (metrics.widthPixels * 0.92).toInt()
            params.height = WindowManager.LayoutParams.WRAP_CONTENT
            w.attributes = params
        }

        tvWord = findViewById(R.id.tvWord)
        tvPhonetic = findViewById(R.id.tvPhonetic)
        tvPartOfSpeech = findViewById(R.id.tvPartOfSpeech)
        tvMeaningEn = findViewById(R.id.tvMeaningEn)
        tvHindiLabel = findViewById(R.id.tvHindiLabel)
        tvMeaningHi = findViewById(R.id.tvMeaningHi)
        tvSynonymsLabel = findViewById(R.id.tvSynonymsLabel)
        tvSynonyms = findViewById(R.id.tvSynonyms)
        tvAntonymsLabel = findViewById(R.id.tvAntonymsLabel)
        tvAntonyms = findViewById(R.id.tvAntonyms)
        progressBar = findViewById(R.id.progressBar)
        btnSpeak = findViewById(R.id.btnSpeak)

        tts = TextToSpeech(this, this)
        btnSpeak.setOnClickListener {
            if (currentWord.isNotBlank()) {
                tts?.speak(currentWord, TextToSpeech.QUEUE_FLUSH, null, "utt1")
            }
        }

        val selected = intent?.getCharSequenceExtra(Intent.EXTRA_PROCESS_TEXT)?.toString()?.trim()

        if (selected.isNullOrBlank()) {
            Toast.makeText(this, "No word selected", Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        val firstToken = selected.split(Regex("\\s+")).firstOrNull { it.isNotBlank() } ?: selected
        isHindiInput = firstToken.any { it in '\u0900'..'\u097F' }

        if (isHindiInput) {
            val hindiWord = firstToken.replace(Regex("[^\\p{L}\\p{N}]"), "").trim()
            if (hindiWord.isBlank()) {
                Toast.makeText(this, "No valid word selected", Toast.LENGTH_SHORT).show()
                finish()
                return
            }
            tvWord.text = hindiWord
            currentWord = hindiWord
            setResultTextsVisible(false)
            progressBar.visibility = View.VISIBLE
            lookupHindiToEnglish(hindiWord)
        } else {
            currentWord = firstToken
                .replace(Regex("[^\\p{L}\\p{N}'-]"), "")
                .trim()
                .lowercase(Locale.US)

            if (currentWord.isBlank()) {
                Toast.makeText(this, "No valid word selected", Toast.LENGTH_SHORT).show()
                finish()
                return
            }

            val displayWord = firstToken.replace(Regex("[^\\p{L}\\p{N}'-]"), "").trim()
            tvWord.text = displayWord.replaceFirstChar {
                if (it.isLowerCase()) it.titlecase(Locale.US) else it.toString()
            }

            setResultTextsVisible(false)
            progressBar.visibility = View.VISIBLE
            lookupWord(currentWord)
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts?.language = Locale.US
        }
    }

    private fun setResultTextsVisible(visible: Boolean) {
        val v = if (visible) View.VISIBLE else View.GONE
        tvPhonetic.visibility = v
        tvPartOfSpeech.visibility = v
        tvMeaningEn.visibility = v
        tvHindiLabel.visibility = v
        tvMeaningHi.visibility = v
        if (!visible) {
            tvSynonymsLabel.visibility = View.GONE
            tvSynonyms.visibility = View.GONE
            tvAntonymsLabel.visibility = View.GONE
            tvAntonyms.visibility = View.GONE
        }
    }

    /** Hindi word selected → translate to English, then look up definition. */
    private fun lookupHindiToEnglish(hindiWord: String) {
        Thread {
            val englishWord = translateHindiToEnglish(hindiWord)
            if (englishWord.isNullOrBlank()) {
                runOnUiThread {
                    progressBar.visibility = View.GONE
                    tvMeaningEn.visibility = View.VISIBLE
                    tvMeaningEn.text = "Could not translate this Hindi word. Check spelling or internet."
                }
                return@Thread
            }

            currentWord = englishWord  // for TTS
            var result = OfflineDictionary.lookup(englishWord)
            var dict: DictResult? = if (result != null) {
                DictResult(
                    phonetic = result.ipa,
                    partOfSpeech = result.partOfSpeech,
                    meaning = result.meaning,
                    hindi = result.hindi,
                    synonyms = result.synonyms,
                    antonyms = result.antonyms
                )
            } else null

            if (dict == null || dict.meaning.isBlank()) {
                dict = tryFetchDictionaryApiDev(englishWord)
            }
            if (dict == null || dict.meaning.isBlank()) {
                dict = tryFetchFreeDictionaryApiCom(englishWord)
            }
            if (dict == null || dict.meaning.isBlank()) {
                dict = tryFetchSuvankar(englishWord)
            }

            val final = dict
            runOnUiThread {
                progressBar.visibility = View.GONE
                if (final == null || final.meaning.isBlank()) {
                    // At least show the translation
                    tvMeaningEn.visibility = View.VISIBLE
                    tvMeaningEn.text = "English: $englishWord"
                    tvHindiLabel.text = getString(R.string.hindi_label)
                    tvHindiLabel.visibility = View.VISIBLE
                    tvMeaningHi.visibility = View.VISIBLE
                    tvMeaningHi.text = hindiWord
                } else {
                    // Show Hindi original + English translation + definition
                    showResult(
                        final.copy(
                            // put English translation in the "hindi" slot and relabel
                            hindi = englishWord
                        ),
                        hindiToEnglishMode = true,
                        originalHindi = hindiWord
                    )
                }
            }
        }.start()
    }

    private fun translateHindiToEnglish(hindi: String): String? {
        return try {
            val q = URLEncoder.encode(hindi, "UTF-8")
            val url = URL("https://api.mymemory.translated.net/get?q=$q&langpair=hi|en")
            val conn = openConn(url)
            if (conn.responseCode == 200) {
                val body = conn.inputStream.bufferedReader().use { it.readText() }
                val json = JSONObject(body)
                val t = json.optJSONObject("responseData")?.optString("translatedText", "") ?: ""
                conn.disconnect()
                if (t.isNotBlank() && !t.contains("MYMEMORY WARNING", ignoreCase = true)
                    && !t.contains("QUERY LENGTH", ignoreCase = true)
                ) {
                    // take first English word
                    return t.trim().lowercase(Locale.US).split(Regex("\\s+")).firstOrNull()
                }
            } else {
                conn.disconnect()
            }
            null
        } catch (_: Exception) {
            null
        }
    }

    private fun lookupWord(word: String) {
        // 1) Instant offline lookup
        val offline = OfflineDictionary.lookup(word)
        if (offline != null) {
            progressBar.visibility = View.GONE
            showResult(
                DictResult(
                    phonetic = offline.ipa,
                    partOfSpeech = offline.partOfSpeech,
                    meaning = offline.meaning,
                    hindi = offline.hindi,
                    synonyms = offline.synonyms,
                    antonyms = offline.antonyms
                )
            )
            return
        }

        // 2) Online – three free sources
        Thread {
            var result: DictResult? = null

            result = tryFetchDictionaryApiDev(word)
            if (result == null || result.meaning.isBlank()) {
                result = tryFetchFreeDictionaryApiCom(word)
            }
            if (result == null || result.meaning.isBlank()) {
                result = tryFetchSuvankar(word)
            }

            var hindi = result?.hindi ?: ""
            if (hindi.isBlank() && result != null && result.meaning.isNotBlank()) {
                hindi = fetchHindiBestEffort(word)
            }

            val finalResult = if (result != null && result.meaning.isNotBlank()) {
                result.copy(hindi = hindi.ifBlank { result.hindi })
            } else null

            runOnUiThread {
                progressBar.visibility = View.GONE
                if (finalResult == null) {
                    tvMeaningEn.visibility = View.VISIBLE
                    tvMeaningEn.text = getString(R.string.network_error)
                } else {
                    showResult(finalResult)
                }
            }
        }.start()
    }

    private fun showResult(
        r: DictResult,
        hindiToEnglishMode: Boolean = false,
        originalHindi: String = ""
    ) {
        setResultTextsVisible(true)

        if (hindiToEnglishMode && originalHindi.isNotBlank()) {
            tvWord.text = originalHindi
            // Speak the English translation
            currentWord = r.hindi.ifBlank { currentWord }
        }

        tvPhonetic.text = r.phonetic
        tvPhonetic.visibility = if (r.phonetic.isBlank()) View.GONE else View.VISIBLE

        tvPartOfSpeech.text = r.partOfSpeech
        tvPartOfSpeech.visibility = if (r.partOfSpeech.isBlank()) View.GONE else View.VISIBLE

        if (hindiToEnglishMode) {
            // Meaning = English definition; secondary line = English word
            tvMeaningEn.text = r.meaning
            tvHindiLabel.text = "English"
            if (r.hindi.isNotBlank()) {
                tvMeaningHi.text = r.hindi.replaceFirstChar {
                    if (it.isLowerCase()) it.titlecase(Locale.US) else it.toString()
                }
                tvHindiLabel.visibility = View.VISIBLE
                tvMeaningHi.visibility = View.VISIBLE
            } else {
                tvHindiLabel.visibility = View.GONE
                tvMeaningHi.visibility = View.GONE
            }
        } else {
            tvMeaningEn.text = r.meaning
            tvHindiLabel.text = getString(R.string.hindi_label)
            if (r.hindi.isNotBlank() && r.hindi != "—") {
                tvMeaningHi.text = r.hindi
                tvHindiLabel.visibility = View.VISIBLE
                tvMeaningHi.visibility = View.VISIBLE
            } else {
                tvHindiLabel.visibility = View.GONE
                tvMeaningHi.visibility = View.GONE
            }
        }

        if (r.synonyms.isNotEmpty()) {
            tvSynonymsLabel.visibility = View.VISIBLE
            tvSynonyms.visibility = View.VISIBLE
            tvSynonyms.text = r.synonyms.take(8).joinToString(", ")
        } else {
            tvSynonymsLabel.visibility = View.GONE
            tvSynonyms.visibility = View.GONE
        }

        if (r.antonyms.isNotEmpty()) {
            tvAntonymsLabel.visibility = View.VISIBLE
            tvAntonyms.visibility = View.VISIBLE
            tvAntonyms.text = r.antonyms.take(6).joinToString(", ")
        } else {
            tvAntonymsLabel.visibility = View.GONE
            tvAntonyms.visibility = View.GONE
        }
    }

    // ---------- Online APIs ----------
    private fun tryFetchDictionaryApiDev(word: String): DictResult? {
        return try {
            val encoded = URLEncoder.encode(word, "UTF-8")
            val url = URL("https://api.dictionaryapi.dev/api/v2/entries/en/$encoded")
            val conn = openConn(url)
            if (conn.responseCode != 200) {
                conn.disconnect()
                return null
            }
            val body = conn.inputStream.bufferedReader().use { it.readText() }
            conn.disconnect()

            val arr = JSONArray(body)
            if (arr.length() == 0) return null
            val entry = arr.getJSONObject(0)

            var phonetic = entry.optString("phonetic", "")
            if (phonetic.isBlank()) {
                val phonetics = entry.optJSONArray("phonetics")
                if (phonetics != null) {
                    for (i in 0 until phonetics.length()) {
                        val p = phonetics.getJSONObject(i).optString("text", "")
                        if (p.isNotBlank()) {
                            phonetic = p
                            break
                        }
                    }
                }
            }

            var partOfSpeech = ""
            var meaning = ""
            val synonyms = mutableListOf<String>()
            val antonyms = mutableListOf<String>()

            val meanings = entry.optJSONArray("meanings")
            if (meanings != null && meanings.length() > 0) {
                val first = meanings.getJSONObject(0)
                partOfSpeech = first.optString("partOfSpeech", "")
                val defs = first.optJSONArray("definitions")
                if (defs != null && defs.length() > 0) {
                    meaning = defs.getJSONObject(0).optString("definition", "")
                }
                for (m in 0 until meanings.length()) {
                    val meaningObj = meanings.getJSONObject(m)
                    collectStrings(meaningObj.optJSONArray("synonyms"), synonyms)
                    collectStrings(meaningObj.optJSONArray("antonyms"), antonyms)
                    val dArr = meaningObj.optJSONArray("definitions")
                    if (dArr != null) {
                        for (d in 0 until dArr.length()) {
                            val dObj = dArr.getJSONObject(d)
                            collectStrings(dObj.optJSONArray("synonyms"), synonyms)
                            collectStrings(dObj.optJSONArray("antonyms"), antonyms)
                        }
                    }
                }
            }

            if (meaning.isBlank()) null
            else DictResult(phonetic, partOfSpeech, meaning, "", synonyms, antonyms)
        } catch (_: Exception) {
            null
        }
    }

    private fun tryFetchFreeDictionaryApiCom(word: String): DictResult? {
        return try {
            val encoded = URLEncoder.encode(word, "UTF-8")
            val url = URL("https://freedictionaryapi.com/api/v1/entries/en/$encoded")
            val conn = openConn(url)
            if (conn.responseCode != 200) {
                conn.disconnect()
                return null
            }
            val body = conn.inputStream.bufferedReader().use { it.readText() }
            conn.disconnect()

            val root = JSONObject(body)
            val entries = root.optJSONArray("entries") ?: return null
            if (entries.length() == 0) return null

            val first = entries.getJSONObject(0)
            val partOfSpeech = first.optString("partOfSpeech", "")

            var phonetic = ""
            val pronunciations = first.optJSONArray("pronunciations")
            if (pronunciations != null) {
                for (i in 0 until pronunciations.length()) {
                    val p = pronunciations.getJSONObject(i)
                    val text = p.optString("text", "")
                    if (text.isNotBlank()) {
                        phonetic = text
                        break
                    }
                }
            }

            var meaning = ""
            val senses = first.optJSONArray("senses")
            if (senses != null && senses.length() > 0) {
                val sense = senses.getJSONObject(0)
                val defs = sense.optJSONArray("definitions")
                if (defs != null && defs.length() > 0) {
                    meaning = defs.optString(0, "")
                } else {
                    meaning = sense.optString("definition", "")
                }
            }
            if (meaning.isBlank()) {
                meaning = first.optString("definition", "")
            }

            val synonyms = mutableListOf<String>()
            val antonyms = mutableListOf<String>()
            collectStrings(first.optJSONArray("synonyms"), synonyms)
            collectStrings(first.optJSONArray("antonyms"), antonyms)

            if (meaning.isBlank()) null
            else DictResult(phonetic, partOfSpeech, meaning, "", synonyms, antonyms)
        } catch (_: Exception) {
            null
        }
    }

    private fun tryFetchSuvankar(word: String): DictResult? {
        return try {
            val encoded = URLEncoder.encode(word, "UTF-8")
            val url = URL("https://api.suvankar.cc/dictionaryapi/v1/definitions/en/$encoded")
            val conn = openConn(url)
            if (conn.responseCode != 200) {
                conn.disconnect()
                return null
            }
            val body = conn.inputStream.bufferedReader().use { it.readText() }
            conn.disconnect()

            val root = JSONObject(body)
            val ipa = root.optString("ipa", "")
            val meaningsArr = root.optJSONArray("meanings") ?: return null
            if (meaningsArr.length() == 0) return null

            var partOfSpeech = ""
            var meaning = ""
            val synonyms = mutableListOf<String>()
            val antonyms = mutableListOf<String>()

            for (m in 0 until meaningsArr.length()) {
                val meaningObj = meaningsArr.getJSONObject(m)
                if (partOfSpeech.isBlank()) {
                    partOfSpeech = meaningObj.optString("partOfSpeech", "")
                }
                val senses = meaningObj.optJSONArray("senses")
                if (senses != null) {
                    for (s in 0 until senses.length()) {
                        val sense = senses.getJSONObject(s)
                        val glosses = sense.optJSONArray("glosses")
                        if (meaning.isBlank() && glosses != null && glosses.length() > 0) {
                            meaning = glosses.optString(0, "")
                        }
                        collectStrings(sense.optJSONArray("synonyms"), synonyms)
                        collectStrings(sense.optJSONArray("antonyms"), antonyms)
                    }
                }
            }

            if (meaning.isBlank()) null
            else DictResult(ipa, partOfSpeech, meaning, "", synonyms, antonyms)
        } catch (_: Exception) {
            null
        }
    }

    private fun fetchHindiBestEffort(word: String): String {
        return try {
            val q = URLEncoder.encode(word, "UTF-8")
            val hiUrl = URL("https://api.mymemory.translated.net/get?q=$q&langpair=en|hi")
            val hiConn = openConn(hiUrl)
            if (hiConn.responseCode == 200) {
                val body = hiConn.inputStream.bufferedReader().use { it.readText() }
                val json = JSONObject(body)
                val t = json.optJSONObject("responseData")?.optString("translatedText", "") ?: ""
                if (t.isNotBlank() && !t.contains("MYMEMORY WARNING", ignoreCase = true)
                    && t.any { it in '\u0900'..'\u097F' }
                ) {
                    hiConn.disconnect()
                    return t
                }
            }
            hiConn.disconnect()
            ""
        } catch (_: Exception) {
            ""
        }
    }

    private fun openConn(url: URL): HttpURLConnection {
        val conn = url.openConnection() as HttpURLConnection
        conn.requestMethod = "GET"
        conn.connectTimeout = 9000
        conn.readTimeout = 9000
        conn.setRequestProperty("User-Agent", "SauravPopupDictionary/1.3 (Android)")
        conn.setRequestProperty("Accept", "application/json")
        conn.instanceFollowRedirects = true
        return conn
    }

    private fun collectStrings(arr: JSONArray?, into: MutableList<String>) {
        if (arr == null) return
        for (i in 0 until arr.length()) {
            val s = arr.optString(i, "")
            if (s.isNotBlank() && !into.contains(s)) into.add(s)
        }
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}
