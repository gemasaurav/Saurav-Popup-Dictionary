# Saurav Popup Dictionary — Android source

Floating popup dictionary that works **online for any English word** and also has a built-in offline list for instant results on common words.

## How lookup works

1. **Offline first** – ~120 common words return instantly with no internet.
2. **Online** – for every other word the app tries three free sources in order:
   - `api.dictionaryapi.dev`
   - `freedictionaryapi.com` (Wiktionary)
   - `api.suvankar.cc` (same source used by the working HTML dictionary)
3. Hindi meaning is fetched best-effort and never blocks the English result.

## Build

Zip the `SauravPopupDictionary` folder → upload as `files.zip` to GitHub → use the corrected workflow,  
or open the project in Android Studio and Build APK.

The included debug keystore keeps the same signature across rebuilds.
