# Saurav Popup Dictionary

Large floating popup dictionary for Android.

## Features

- **Large readable card** (~92% screen width) – text is never cut off; long definitions scroll.
- **English → Hindi**: select an English word → meaning + Hindi translation.
- **Hindi → English**: select a Hindi (Devanagari) word → English translation + English definition.
- **Offline** for ~120 common words (instant).
- **Online** for any other word via three free APIs.

## Build

Zip the `SauravPopupDictionary` folder and use GitHub Actions, or open in Android Studio and Build APK.
