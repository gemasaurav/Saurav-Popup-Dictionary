# Saurav Popup Dictionary

Android popup dictionary that appears in the system text-selection menu.

When you long-press any word in almost any app (Chrome, WhatsApp, PDF, Notes…),  
you will see **“Saurav Popup Dictionary”** in the menu.  
Tapping it opens a beautiful glass-style popup with:

- English meaning + part of speech  
- Hindi meaning  
- Pronunciation (phonetic + audio when available)  
- Synonyms & Antonyms  

## How to build & install

### Option A – Android Studio (recommended)

1. Open **Android Studio**
2. **File → New → New Project → Empty Activity**
3. Settings:
   - Name: `SauravPopupDictionary`
   - Package: `com.saurav.popupdictionary`
   - Language: **Kotlin**
   - Minimum SDK: **API 24**
4. After the project is created, **replace / copy** the files from this repository into the matching folders:
   - `app/src/main/AndroidManifest.xml`
   - `app/src/main/java/com/saurav/popupdictionary/`
   - `app/src/main/res/`
5. Make sure these dependencies are in `app/build.gradle.kts` (or `.gradle`):

```kotlin
dependencies {
    implementation("androidx.core:core-ktx:1.12.0")
    implementation("androidx.appcompat:appcompat:1.6.1")
    implementation("com.google.android.material:material:1.11.0")
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.7.3")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.7.0")
}
```

6. Click **Sync Now**
7. **Build → Build Bundle(s) / APK(s) → Build APK(s)**
8. Install the APK on your phone

### Option B – Put on GitHub

1. Create a new repository on GitHub named `Saurav-Popup-Dictionary`
2. Upload the entire `SauravPopupDictionary` folder
3. Clone it on any computer that has Android Studio and follow Option A

## How it works

- The activity `PopupDictionaryActivity` is registered for  
  `android.intent.action.PROCESS_TEXT`
- Android automatically adds the app name to the text-selection toolbar
- When the user taps it, the selected word is passed via `Intent.EXTRA_PROCESS_TEXT`
- The app fetches definitions from free public APIs and shows a floating glass popup

## Free Dictionary APIs used

1. Primary: https://freedictionaryapi.com  
2. Fallback: https://api.suvankar.cc  
3. Hindi: https://api.mymemory.translated.net  

No API key required.

## Notes

- Internet permission is required.
- The popup closes when you tap outside it.
- Works on Android 7.0 (API 24) and above.
