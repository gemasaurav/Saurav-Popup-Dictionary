package com.saurav.popupdictionary

import android.content.Intent
import android.media.MediaPlayer
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

class PopupDictionaryActivity : AppCompatActivity() {

    private lateinit var loadingBox: LinearLayout
    private lateinit var contentBox: LinearLayout
    private lateinit var tvError: TextView
    private lateinit var tvWord: TextView
    private lateinit var tvPhonetic: TextView
    private lateinit var tvHindi: TextView
    private lateinit var meaningsContainer: LinearLayout
    private lateinit var tvSynonyms: TextView
    private lateinit var tvAntonyms: TextView
    private lateinit var btnAudio: Button
    private lateinit var btnClose: ImageButton

    private var audioUrl: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_popup)

        loadingBox = findViewById(R.id.loadingBox)
        contentBox = findViewById(R.id.contentBox)
        tvError = findViewById(R.id.tvError)
        tvWord = findViewById(R.id.tvWord)
        tvPhonetic = findViewById(R.id.tvPhonetic)
        tvHindi = findViewById(R.id.tvHindi)
        meaningsContainer = findViewById(R.id.meaningsContainer)
        tvSynonyms = findViewById(R.id.tvSynonyms)
        tvAntonyms = findViewById(R.id.tvAntonyms)
        btnAudio = findViewById(R.id.btnAudio)
        btnClose = findViewById(R.id.btnClose)

        btnClose.setOnClickListener { finish() }
        findViewById<View>(R.id.root).setOnClickListener { finish() }
        findViewById<View>(R.id.card).setOnClickListener { /* consume click */ }

        btnAudio.setOnClickListener {
            audioUrl?.let { url ->
                try {
                    MediaPlayer().apply {
                        setDataSource(url)
                        prepare()
                        start()
                    }
                } catch (_: Exception) { }
            }
        }

        val selected = intent.getCharSequenceExtra(Intent.EXTRA_PROCESS_TEXT)
            ?.toString()?.trim()?.lowercase()
            ?.replace(Regex("[^a-z\\-']"), "")
            ?: ""

        if (selected.isBlank()) {
            showError("No word selected")
            return
        }

        tvWord.text = selected
        lookup(selected)
    }

    private fun lookup(word: String) {
        loadingBox.visibility = View.VISIBLE
        contentBox.visibility = View.GONE
        tvError.visibility = View.GONE

        lifecycleScope.launch {
            val result = withContext(Dispatchers.IO) { fetchDictionary(word) }
            if (result != null) {
                showResult(result)
            } else {
                showError("Unable to fetch definition.\nPlease check your connection and try again.")
            }
        }
    }

    private data class DictResult(
        val word: String,
        val phonetic: String,
        val audio: String?,
        val hindi: String,
        val meanings: List<Pair<String, List<String>>>, // POS -> list of definitions
        val synonyms: List<String>,
        val antonyms: List<String>
    )

    private fun fetchDictionary(word: String): DictResult? {
        // 1. Primary: freedictionaryapi.com
        try {
            val url = URL("https://freedictionaryapi.com/api/v1/entries/en/${URLEncoder.encode(word, "UTF-8")}")
            val conn = url.openConnection() as HttpURLConnection
            conn.connectTimeout = 9000
            conn.readTimeout = 9000
            conn.requestMethod = "GET"
            if (conn.responseCode == 200) {
                val json = conn.inputStream.bufferedReader().readText()
                val obj = JSONObject(json)
                return parseFreedictionaryAPI(obj, word)
            }
        } catch (_: Exception) { }

        // 2. Fallback: api.suvankar.cc
        try {
            val url = URL("https://api.suvankar.cc/dictionaryapi/v1/definitions/en/${URLEncoder.encode(word, "UTF-8")}")
            val conn = url.openConnection() as HttpURLConnection
            conn.connectTimeout = 8000
            conn.readTimeout = 8000
            if (conn.responseCode == 200) {
                val json = conn.inputStream.bufferedReader().readText()
                val obj = JSONObject(json)
                return parseSuvankar(obj, word)
            }
        } catch (_: Exception) { }

        return null
    }

    private fun parseFreedictionaryAPI(obj: JSONObject, word: String): DictResult {
        var phonetic = ""
        var audio: String? = null
        val meanings = mutableListOf<Pair<String, List<String>>>()
        val syn = mutableSetOf<String>()
        val ant = mutableSetOf<String>()

        val entries = obj.optJSONArray("entries") ?: JSONArray()
        for (i in 0 until entries.length()) {
            val entry = entries.getJSONObject(i)
            val pos = entry.optString("partOfSpeech", "unknown")

            if (phonetic.isEmpty()) {
                val prons = entry.optJSONArray("pronunciations")
                if (prons != null && prons.length() > 0) {
                    phonetic = prons.getJSONObject(0).optString("text", "")
                }
            }

            val senses = entry.optJSONArray("senses") ?: JSONArray()
            val defs = mutableListOf<String>()
            for (j in 0 until senses.length()) {
                val s = senses.getJSONObject(j)
                val def = s.optString("definition", "")
                if (def.isNotBlank()) defs.add(def)

                val sSyn = s.optJSONArray("synonyms")
                if (sSyn != null) for (k in 0 until sSyn.length()) syn.add(sSyn.getString(k))
                val sAnt = s.optJSONArray("antonyms")
                if (sAnt != null) for (k in 0 until sAnt.length()) ant.add(sAnt.getString(k))
            }
            if (defs.isNotEmpty()) meanings.add(pos to defs)
        }

        val hindi = fetchHindi(word)
        return DictResult(word, phonetic, audio, hindi, meanings, syn.toList(), ant.toList())
    }

    private fun parseSuvankar(obj: JSONObject, word: String): DictResult {
        val phonetic = obj.optString("ipa", "")
        val audio = obj.optString("audioUrl", null)
        val meanings = mutableListOf<Pair<String, List<String>>>()
        val syn = mutableSetOf<String>()
        val ant = mutableSetOf<String>()

        val mArr = obj.optJSONArray("meanings") ?: JSONArray()
        for (i in 0 until mArr.length()) {
            val m = mArr.getJSONObject(i)
            val pos = m.optString("partOfSpeech", "unknown")
            val senses = m.optJSONArray("senses") ?: JSONArray()
            val defs = mutableListOf<String>()
            for (j in 0 until senses.length()) {
                val s = senses.getJSONObject(j)
                val glosses = s.optJSONArray("glosses")
                if (glosses != null && glosses.length() > 0) {
                    defs.add(glosses.getString(0))
                }
            }
            if (defs.isNotEmpty()) meanings.add(pos to defs)
        }

        val hindi = fetchHindi(word)
        return DictResult(word, phonetic, audio, hindi, meanings, syn.toList(), ant.toList())
    }

    private fun fetchHindi(word: String): String {
        return try {
            val url = URL("https://api.mymemory.translated.net/get?q=${URLEncoder.encode(word, "UTF-8")}&langpair=en|hi")
            val conn = url.openConnection() as HttpURLConnection
            conn.connectTimeout = 6000
            conn.readTimeout = 6000
            if (conn.responseCode == 200) {
                val json = JSONObject(conn.inputStream.bufferedReader().readText())
                val t = json.optJSONObject("responseData")?.optString("translatedText") ?: ""
                if (t.isNotBlank() && !t.contains("MYMEMORY WARNING") && !t.contains("QUERY LENGTH")) t else "—"
            } else "—"
        } catch (_: Exception) {
            "—"
        }
    }

    private fun showResult(r: DictResult) {
        loadingBox.visibility = View.GONE
        contentBox.visibility = View.VISIBLE
        tvError.visibility = View.GONE

        tvWord.text = r.word
        tvPhonetic.text = r.phonetic
        tvPhonetic.visibility = if (r.phonetic.isBlank()) View.GONE else View.VISIBLE
        tvHindi.text = r.hindi

        audioUrl = r.audio
        btnAudio.visibility = if (r.audio.isNullOrBlank()) View.GONE else View.VISIBLE

        meaningsContainer.removeAllViews()
        r.meanings.forEach { (pos, defs) ->
            val posTv = TextView(this).apply {
                text = pos.uppercase()
                setTextColor(0xFF5B9CFF.toInt())
                textSize = 12f
                setPadding(0, 12, 0, 4)
                setTypeface(null, android.graphics.Typeface.BOLD)
            }
            meaningsContainer.addView(posTv)

            defs.take(3).forEachIndexed { idx, def ->
                val defTv = TextView(this).apply {
                    text = "${idx + 1}. $def"
                    setTextColor(0xFFE8EEF8.toInt())
                    textSize = 14.5f
                    setPadding(12, 4, 0, 6)
                    setBackgroundColor(0x12FFFFFF)
                }
                meaningsContainer.addView(defTv)
            }
        }

        tvSynonyms.text = if (r.synonyms.isEmpty()) "—" else r.synonyms.take(12).joinToString("  •  ")
        tvAntonyms.text = if (r.antonyms.isEmpty()) "—" else r.antonyms.take(8).joinToString("  •  ")
    }

    private fun showError(msg: String) {
        loadingBox.visibility = View.GONE
        contentBox.visibility = View.GONE
        tvError.visibility = View.VISIBLE
        tvError.text = msg
    }
}
